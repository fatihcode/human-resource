import React, { useState, useEffect } from 'react'
import { Carousel, Container } from 'react-bootstrap'
import CarouselItem from './CarouselItem'

import { useDispatch } from 'react-redux'

// const INITIAL_STATE = [
//    { title: "First slide label", url: "artboard_1.jpg", caption: "Nulla vitae elit libero, a pharetra augue mollis interdum." },
//    { title: "Second slide label", url: "artboard_2.jpg", caption: "Lorem ipsum dolor sit amet, consectetur adipiscing elit." },
//    { title: "Third slide label", url: "artboard_3.jpg", caption: "Nulla vitae elit libero, a pharetra augue mollis interdum." },
//    { title: "Fourth slide label", url: "artboard_4.jpg", caption: "Praesent commodo cursus magna, vel scelerisque nisl consectetur." }
// ]


export default function Home() {

   // const [slider, setSlider] = useState(INITIAL_STATE)


   return (
      <Container>

         <Carousel variant="dark" className="mb-4">

            {/* {slider.map((item, i) => <CarouselItem key={i} slide={item} />)} */}

            <Carousel.Item>
               <img className="d-block w-100" src="img/artboard_1.jpg" alt="First slide" />
               <Carousel.Caption>
                  <h5>First slide label</h5>
                  <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
               </Carousel.Caption>
            </Carousel.Item>

            <Carousel.Item>
               <img className="d-block w-100" src="img/artboard_2.jpg" alt="Second slide" />
               <Carousel.Caption>
                  <h5>Second slide label</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
               </Carousel.Caption>
            </Carousel.Item>

            <Carousel.Item>
               <img className="d-block w-100" src="img/artboard_3.jpg" alt="Third slide" />
               <Carousel.Caption>
                  <h5>Third slide label</h5>
                  <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
               </Carousel.Caption>
            </Carousel.Item>

            <Carousel.Item>
               <img className="d-block w-100" src="img/artboard_4.jpg" alt="Third slide" />
               <Carousel.Caption>
                  <h5>Third slide label</h5>
                  <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
               </Carousel.Caption>
            </Carousel.Item>


         </Carousel>


         


      

         <section className="page-section bg-light" id="team">
            <div className="container">
               <div className="text-center">
                  <h2 className="section-heading text-uppercase">Our Amazing Team</h2>
                  <h3 className="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
               </div>
               <div className="row">
                  <div className="col-lg-4">
                     <div className="team-member">
                        <img className="mx-auto rounded-circle" src="assets/img/team/1.jpg" alt="..." />
                        <h4>Parveen Anand</h4>
                        <p className="text-muted">Lead Designer</p>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-twitter"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-facebook-f"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-linkedin-in"></i></a>
                     </div>
                  </div>
                  <div className="col-lg-4">
                     <div className="team-member">
                        <img className="mx-auto rounded-circle" src="assets/img/team/2.jpg" alt="..." />
                        <h4>Diana Petersen</h4>
                        <p className="text-muted">Lead Marketer</p>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-twitter"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-facebook-f"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-linkedin-in"></i></a>
                     </div>
                  </div>
                  <div className="col-lg-4">
                     <div className="team-member">
                        <img className="mx-auto rounded-circle" src="assets/img/team/3.jpg" alt="..." />
                        <h4>Larry Parker</h4>
                        <p className="text-muted">Lead Developer</p>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-twitter"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-facebook-f"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-linkedin-in"></i></a>
                     </div>
                  </div>
               </div>
               <div className="row">
                  <div className="col-lg-8 mx-auto text-center"><p className="large text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.</p></div>
               </div>
            </div>
         </section>

        

         <div className="py-5">
            <div className="container">
               <div className="row align-items-center">
                  <div className="col-md-3 col-sm-6 my-3">
                     <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src="assets/img/logos/microsoft.svg" alt="..." /></a>
                  </div>
                  <div className="col-md-3 col-sm-6 my-3">
                     <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src="assets/img/logos/google.svg" alt="..." /></a>
                  </div>
                  <div className="col-md-3 col-sm-6 my-3">
                     <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src="assets/img/logos/facebook.svg" alt="..." /></a>
                  </div>
                  <div className="col-md-3 col-sm-6 my-3">
                     <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src="assets/img/logos/ibm.svg" alt="..." /></a>
                  </div>
               </div>
            </div>
         </div>



      </Container>

   )
}